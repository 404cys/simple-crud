import pool from '../config/dbConfig.js';


export const getAllUsersService= async () => { 
    try { 
        const result = await pool.query("SELECT * FROM users"); 
        return result.rows; 
    } catch (e) { 
        console.error(`Error getting all users: ${e}`);
        return null; 
    }
};


export const getUserByIdService= async (id) => { 
    try { 
        const result = await pool.query("SELECT * FROM users WHERE id = $1", [id]); 
        return result.rows[0] || null; 
    } catch (e) { 
        console.error(`Error getting user by ID:  ${e}`);
        return null;
    }
};


export const addUserService = async (name, email, password, role = "user") => { 

    try {
        if (!name || !email || !password) { 
            throw new Error("All fields (name, email, password) are required!");
        }
        const hashPassword =  await bcrypt.hash(password ,10) ; 

        const result = await pool.query(
            "INSERT INTO users (name, email, password, role) VALUES ($1, $2, $3, $4) RETURNING *",
            [name, email, hashPassword , role]
        );
        return result.rows[0]; 
    } catch (e) { 
        console.error(`Error adding user: ${e.message}`);
        throw e;  
    }
};



export const updateUserService= async (id, name, email) => {
    try {
        const result = await pool.query(
            "UPDATE users SET name = $1, email = $2 WHERE id = $3 RETURNING *",
            [name, email, id]
        );
        return result.rows[0] || null;
    } catch (e) {
        console.error(`Error updating user:  ${e}`);
        return null;
    }
};


export const deleteUserService= async (id) => {
    try {
        const result = await pool.query(
            "DELETE FROM users WHERE id = $1 RETURNING *",
            [id]
        );
        return result.rows[0] || null;
    } catch (e) {
        console.error(`Error deleting user:  ${e}`);
        return null;
    }
};

import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import pool from "../config/dbConfig.js";
import dotenv from "dotenv";


dotenv.config() ; 

const JWT_SECRT = process.env.JWT_SECRT ; 

const generateToken =(user) => { 
    return jwt.sign(
        {
            id: user.id ,
            email : user.email , 
            role : user.role
        },
        JWT_SECRT, 
        {expiresIn : "1d"}
    ); 

} ; 


import bcrypt from "bcryptjs";
import pool from "../config/dbConfig.js";
import {generateToken} from '../auth/authService.js' ;


export const loginUserService = async (email , password) => { 
    try { 
        const result = await pool.query("SELECT * FROM user WHRER email = $1" , [email]) ; 
        if(result.rows.length === 0) throw new Error ("User Not found :(") ;
        const user = result.rows[0] ; 
        const isMatch = await bcrypt.compare(password , user.password) ; 
        if(!isMatch) throw new Error("Invalid credentials :(");
        const token  = generateToken(user) ; 
        return {user , token };
        
    }catch(e){ 
        throw new Error(error.message) ;
    }
};

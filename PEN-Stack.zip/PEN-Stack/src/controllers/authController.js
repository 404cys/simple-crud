import { loginUserService } from "../auth/loginUserService";



export const loginUser = async(req , res) =>{ 
    try{ 
        const {email , password} = req.body ; 
        if(!email || !password) { 
            return res.status(400).json({ message: "Email and password are required!" });
        }
        const {user , token } = await loginUserService(email , password) ; 
        res.status(200).json({
            message : "Login successful" , 
            user: { id: user.id, name: user.name, email: user.email, role: user.role },
            token
        }); 


    }catch(e){ 
        res.status(401).json({ message: e.message });

    }
}
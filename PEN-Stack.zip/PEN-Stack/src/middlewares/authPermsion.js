import { updateUser } from "../controllers/userController.js";

export const UserPermissionsForUpdate = (req, res, next) => { 
    const { id } = req.params; 
    const { role, userId } = req.user; 

    if (role === "admin" || userId == id) { 
        return updateUser(req, res, next);
    } else { 
        return res.status(403).json({ message: "Request failed" }); 
    }
};

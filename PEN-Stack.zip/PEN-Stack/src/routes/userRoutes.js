import express from 'express';
import {
    addUser, 
    deleteUser,
    getAllUsers, 
    getUserById} 
from '../controllers/userController.js'
import validateUser from '../middlewares/inputValidator.js';
import {verifyToken , authorizeRole} from '../middlewares/authMiddleware.js';
import { UserPermissionsForUpdate } from '../middlewares/authPermsion.js';

const router = express.Router();
router.post('/users' ,verifyToken , authorizeRole(["admin"]), addUser );
router.get('/users' , verifyToken,getAllUsers , authorizeRole(["admin"]),);
router.get('/users/:id' , verifyToken,authorizeRole(["admin"]),getUserById);
router.put('/users/:id' ,validateUser, verifyToken, UserPermissionsForUpdate );
router.delete('/users/:id', verifyToken , authorizeRole(["admin"]) , deleteUser);


export default router;